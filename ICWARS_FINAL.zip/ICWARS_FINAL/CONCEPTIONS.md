<h1>Conceptions</h1>

<h2>Modifications et détails d'implémentation + ajouts (non extension)</h2>
<ul>
<li>Unités : 
<ul>
<li>Modification du nombre de hp maximum
<li> Ajout de la méthode increaseAttack permettant d'augmenter les dégats d'attaque de l'unité
<li>Pour représenter les actions d'une unité nous avons décidé d'utiliser une hashmap car son modèle de key value pair permet de bien représenter l'association de la touche de clavier associé à cette action. De plus ses actions peuvent rapidement être présentée sous forme d'array list sans la key pour différents usages notamment les fournir à la GUI pour les afficher.
<li>Nous avons aussi modifié le nombre d'unités demandées dans la deuxième zone, augmentant le nombre et la variété des unités présentes. 
</ul>
<li>ICWarsPlayer : 
<ul>
<li>Pour enregistrer les unités que le player possède nous avons décidé de simplement donner un nombre paramétrable dans le constructeur pour chaque type d'unité. Nous avons fais ce choix car chaque unité était créée de la même manière et que seul le nombre d'unités de chaque type que possède le joueur est important. Nous trouvons que c'est une meilleure implémentation qu'une elipse.
<li>Nous avons aussi automatisé le placement des unités du joueur. Elles sont placées en ligne droite horizontale à partir d'un point donné formant ainsi un "convoi". Nous avons choisi ceci car si le joueur possède un grand nombre d'unités, cela compliquede manière conséquente la disposition ordonnées d'unités.
<li> Nous avons créé une méthode <i>computeSpriteName</i> qui permet de déterminer le <i>path</i> du sprite du curseur en fonction de la faction (Il peut être <i>Ally</i> ou <i>Enemy</i>). Nous trouvions cela plus pratique que de contrôler la faction dans le constructeur pour attribuer le bon sprite.
<lu>
</ul>
<li>ICWars
<ul>
<li>Pour l'enchainement des joueurs nous avons décidé d'utiliser une  <i>arrayList</i> de tous les joueurs présent sur le jeu une <i>Deque</i> pour les joueurs attendant le prochain tour et une <i>Deque</i> pour les joueurs qui attendent de jouer. Cette liste permet de facilement intéragir sur tous les joueurs. Et les <i>Deque</i> permettent de bien représenter le concept de fil d'attente (First in first Out) et permettent d'aisémant effectuer certaines action demandées comme enlever et ajouter des unités au début et à la fin sans trop d'effort et sans ce soucier des indexes.  	
</ul>
<li>AiPlayer
<ul>
<li>Dans l'automatisation des attaques avons ajouté un contrôle; l'unité ne peut effectuer qu'une action par tour.
<li>Nous avons ajouté l'affichage du curseur d'attaque pour l'AIPlayer afin de rendre plus clair quelle unité est ciblée par l'IA.

</ul>
<li>ICWarsArea: ajout de <i>getAllySpawnUnit</i> et <i>getEnnemySpawnUnit</i> comme expliqué précédemment nous avons changé comment les unités spawn en leur donnant simplement un point de départ d'où une ligne est créée. Ces méthodes permettent de définir ce point propre à chaque <i>area</i> du jeu. Elles sont abstraites car doivent être redéfinies dans chaque extension de cette classe (Le point d'aparition dépend de la taille de la carte et de la volonté de position des unités du dévelopeur).
<li>Nous avons aussi ajouté une méthode abstraite par unité permettant de définir un nombre de chaque type d'unité. Ceci permet à nouveau de rendre plus facile la création de plusieurs niveau en traitant ce processus toujours de la même manière.
</ul>
<ul>
<li>Changement de zone et <i>reload</i>: Lorsque le joueur perd, il recommence automatiquement au début du premier niveau. il peut aussi choisir de passer au niveau suivant en appuyant sur "N".
</ul>
<br></br>


<h1>Extensions</h1>
<p>Information : les détails non techniques des implémentations sont disponibles dans le readme</p>

<ol>
<li>Amélioration des déplacements d'unité : nous avons ajouté le fait que le joueur ne puisse pas se déplacer sur les unités alliées / ennemies / mortes car si codé comme dans le polycopié les unités ne se déplacaient simplement pas mais le déplacement était comptabilisé si on choisissait une case occupée par une autre unité.L'unité peut toujours être déplacée sur elle même pour ne pas bouger pendant son tour mais tout de même attaquer. Nous avons décidé d'implementer ceci car cela nous paraissait un comportement plus logique que celui initiallement prévu. Pour ce faire nous avons simplement ajouté un attribut boolean <i>"canMoveUnit"</i> dans la classe <i>RealPlayer</i> qui prend la valeur fausse si lorsque le joueur est en phase <i>MOVE_UNIT</i> et est sur une unité et est vrai si il est sur une cellue sans unité. La valeure de <i>canMoveUnit</i> est donc controlée avant l'initialisation du mouvement de l'unité.
<br></br>
<li>Mort de l'unité : nous avons modifié la mort des unités au lieu de les faire disparaître, leur <i>sprite</i> prend une apparence détruite et elles gisent sur l'emplacement de leur mort tout le long de la partie. /!\ Étant des carcasses, elles ne sont pas traversable donc on nne peut pas déplacer d'unités sur la même case. (La case est occupée pour toute la durée de la partie). Pour ce faire, nous avons simplement changé le sprite de l'unité et l'effaçons de la liste d'unité du joueur et de la liste d'unité de la liste mais ne la désenregistrons pas. Elle reste donc ici comme unitée "inerte" et non "intéractable".
<br></br>
<li>Ajout d'une unité : le "Geek" (uniquement disponible au niveau 2) Nous avons ajouté l'unité geek qui est un soldier modifié avec moins d'attaque plus de mobilité et une aptitude supplémentaire : le "hack", qui améliore une autre unité alliée (voir ci-dessous). Pour ce faire nous avons simplement rajouté une classe <i>Geek</i> construite de manière analogue à la classe <i>Tank</i> et <i>Soldier</i> et dans le même package que les autres unités.
<br></br>
<li>Ajout d'une autre unité "Boat"(visible uniquement au niveau 5).Simple unité dotée d'un sprite différent des autres et un rayon d'attaque, nombre de dégat, point de vie propre à elle même (voir readme).
<br></br>
<li>Ajout d'une action <i>Hack</i> : nous avons ajouté une action qui est uniquement utilisée par le Geek. Elle permet d'augmenter les points de dégats d'une valeure donnée d'une unitée alliée dans la zone d'attaque de l'unité et augmente par la même occasion les dégats de l'unité qui utilise cette action. Nous avons décidé d'ajouter cette extension car le jeu portant le nom ICwars nous étions obligés d'inclure une référence à l'informatique :). Pour implémenter ceci nous avons simplement rajouter une classe héritant de <i>ICWarsAction</i> analogue à <i>Attack</i> dans le même dossier actions que cette dernière. Il a aussi fallu créer une méthode dans <i>Unit</i> permettant d'augmenter les points de dégats de cette dernière. De plus il a fallu créer une méthode dans <i>ICWarsArea</i> permettant de trouver les alliés dans la range d'attaque de l'unité pour pouvoir intéragir avec eux et augmenter leurs dégats.
<br></br>
<li> Ajout d'une action <i>Patch</i>. Cette action est une action uniquement utilisable par les tanks et elle permet de soigner l'unité qui l'utilise. Pour implémenter ceci nous avons simplement rajouté une classe héritant de <i>ICWarsAction</i> analogue à <i>Attack</i> dans le même dossier actions que cette dernière.L'action utilise la méthode <i>Repair</i> déjà présente du tank.
<br></br>
<li>Ajout de sons : Nous avons ajouté des effets sonores pour l'attaque du tank, l'attaque du soldat, et un soundtrack à volume très faible dans le jeu. Pour ce faire nous avons créer notre propre classe <i>AudioHandler</i> dans le package audio  qui prend simplement un fichier son à son constructeur et dispose d'une méthode <i>playSound</i> qui lance le son en question. Nous n'avons pas implémenté ceci avec le matériel fourni car nous n'avons trouvé aucune documentation (même dans la javadoc) sur les fichiers sonores. Le but étant assez simple nous avons donc préféré construire notre propre classe sans créer d'interface ou de classe abstraite car elle a un unique but qui dans notre cas n'a pas besoin d'être étendu.
<br></br>
<li>Ajout d'un Shop : Pour ajouter un peu d'intéraction dans notre jeu nous avons décidé d'ajouter un Shop. (Voir readme sur utilisation et touche). Pour implémenter le Shop nous avons procédé de manière analogue au déplacement d'unité c'est à dire rajouter deux états au joueur un premier état qui est <i>SELECT_SHOPPING</i> qui lorsqu'on est sur une unité la sélectionne et passe en état <i>SHOPPING</i> (Similairement aux méthodes de séléction puis de déplacement d'unités). La deuxième implémentation nécessaire était les objets car notre but était que le shop vende différents objets. Nous avons donc créé un package dédié à ceci pour garder les choses en rapport au shop directement dans un package shop. Dans ce package nous avons mis une classe Shop (nous y reviendrons plus tard) et un sous package shopitems. Dans ce sous package nous avons créer une classe abstraite ShopItem qui donne une idée générale de ce qu'un item vendu dans le shop aura besoin (prix, nom, et touche d'achat) et une méthode Effet qui décrit l'action que l'objet acheté effectuera. Les objets du Shop pourront donc en hériter. C'est le cas de la classe bierePG. Dans la classe Shop (élement qui gère l'achat des objets et l'exécution de l'effet) . Le joueur possède également un attribut Shop. Pour gérer les éléments graphique du Shop, nous avons créer une classe <i>ShopGUI</i> dans le package GUI. Et avons créer un attribut <i>ShopGui</i> dans la classe <i>ICWarsPlayerGUi</i> qui se charge de l'afficher au moment nécessaire. Dernièrement nous avons ajouté un "porte monnaie " au joueur à l'aide d'un attribut "monnaie" et chaque fois qu'une unité alliée élimine une unité, son joueur gagne de l'argent. Ce processus s'effectue directement dans l'attaque.
<br></br>
<li>Ajout de niveaux (cartes/area) Nous avons ajouté plusieurs niveaux de taille différentes et de nouveaux types de cellules. Notamment une carte totalement aquatique pour mettre nos bateaux et la dernière carte EPFL. Pour créer chaque carte il a d'abord fallu créer les backgrounds des cartes et les behaviors correspondant. Pour ce faire nous avons créer un "tool" en python fourni en annexe (dossier mapcreation (voir readme)). Le tool assemble différentes images de cellules et en fait une image finale et pour chaque type de cellule crée un pixel de couleur correspondante (lié à l'<i>enum</i> dans <i>ICwarsBehavior</i>) à la même position dans une autre image. Puis il a fallu créer les classes correspondant à chaque niveau en spécifiant les points de spawn des unités et joueur et le nombre d'unités plus à quel background/behavior l'associé.
<br></br>
<li>Ajout de nouveux types de cellules ;
   Nous avons ajouté plusieurs types de cellules notamment les pipes(tuyaux) et le sable. Nous avons donc du modifié la GUI du joueur pour ajouter l'affichage des sprites lorsque le joueur est sur la cellule. Pour implémenter les nouvelles cellules il a fallu les ajouter à des cartes (voir point 8) et l'ajouter dans l'enum de <i>ICWarsBehavior</i> avec un code rgb hexadécimal correspondant à celui utilisé dans la <i>behavior map</i> pour la cellule donnée. 
<br></br>
<li>Simple amélioration de l'IA : l'IA soigne son tank lorsqu'il atteint un nombre de point de vie fixé <i>PATCH_THRESHOLD</i>. Et elle contrôle si l'unité possède une action donnée avant de l'utilisé. 
<br></br>
<li>Ajout d'affichage de victoire lorsque le joueur réussi un niveau pour ceci nous avons du créer une classe dans le package GUI. Et avons créé un attribut de cette classe dans la playerGUI, lorsque le joueur gagne (déterminé dans <i>ICwars</i>)  une méthode <i>hasWon</i> est appelée sur le joueur ce qui signale à <i>PlayerGui</i> que le joueur a gagné et qu'il faut afficher le texte de victoire avec les informations pour recommencer ou passer au niveau supérieur.	 (Pour pouvoir tout de même expérimenter toutes les cartes sans forcément réussir les précédentes nous avons laissé la possibilité de passer les niveaux avec la touche N sans avoir réussi le niveau)
<br></br>
<li>Différentier le rayon d'attaque du rayon de déplacement : nous avons décidé de faire une distinction entre les deux car cela paraissait plus réaliste et logique. Pour ce faire nous avons créer un nouvel attribut dans les units qui est <i>attackRay</i> et<i> movingRay</i> et avons adapté les méthodes qui en avait besoin en conséquence.
<br></br>
<li>Les cases impactent le rayon d'attaque ; comme nous avons différentier les deux rayons (cf 12) nous avons décidé que les cellules aient un impact sur le rayon d'attaque indiqué par "obstacles" dans l'enum du type de cellule. L'unité verra son rayon d'attaque réduit sur certains types de cellules. Pour ce faire nous avons procédé de la même manière que pour les <i>Defense stars</i> mais pour les obstacles.
<br></br>
<li> Affichage du rayon d'attaque dans l'<i>info panel</i>; nous avons décidé d'ajouter l'affichage du rayon d'attaque dans les informations quand le joueur se positionne sur l'unité. Nous avons simplement rajouté une indication analogue a celle de l'affichage des points de vies dans le panel d'info mais pour le rayon d'attaque des unités.
<br></br>
<li>Affichage des attaques uniquement lorsque <strong>utilisable</strong> : pour rendre plus claire l'utilisation du jeu. Seules les actions utilisable au moment de la sélection d'attaque sont présentés au joueur (Attaque si une unité ennemie se trouve dans le rayon d'attaque de l'unité ou Patch si les points de vies ne sont pas maximum).Pour ce faire nous avons ajouté une méthode abstraite dans <i>ICwarsAction</i> qui permet de déterminer si l'action peut être utilisée ou non (implémentaiton propre à chaque attaque), si elle ne peut pas être utilisée elle n'est simplement pas donnée à la GUI qui ne l'affiche donc pas.
<br></br>
l'attaque de l'unité ou Patch si les points de vies ne sont pas maximum).Pour ce faire nous avons ajouté une méthode abstraite dans <i>ICwarsAction</i> qui permet de déterminer si l'action peut être utilisée ou non (implémentaiton propre à chaque attaque), si elle ne peut pas être utilisée elle n'est simplement pas donnée à la GUI qui ne l'affiche donc pas.
<br></br>
<li>ajouts de capture de cité : comme sugéré dans les extensions nous avons implémenté l'extension de capture de cité seulement que les cités ramène au joueur de l'argent passivement utilisable dans le shop. Pour ce faire nous avons crée une classe City dans un nouveau sous package de actor dans icwars ce nommant city. Pour gérer les cités il nous a fallu créer plusieurs classes. Notamment :
<ul>
<br>
<li>attribut capturedCity dans realPlayer qui est une liste des cités que le joueur a capturé
<li>nouvelles intéractions avec les cités qui permet de setter la cité sur laquelle l'unité est à l'attribut selectedCity.
<li>nouvelle action capture avec un canBeUsed adapté (seulement si l'unité est placé sur une cellule de type cité)
<li>nouvelle méthode dans ICWarsPlayer qui permet de payer le joueur selon le nombre de cité qu'il a capturé.
<li>méthode qui permet de changer le joueur qui possède la cité dans la classe City.
<l
</ul>
</ol>