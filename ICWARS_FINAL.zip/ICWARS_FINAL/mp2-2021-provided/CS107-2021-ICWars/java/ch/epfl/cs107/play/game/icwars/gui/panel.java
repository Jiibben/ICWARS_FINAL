package ch.epfl.cs107.play.game.icwars.gui;

import ch.epfl.cs107.play.game.actor.Graphics;
import ch.epfl.cs107.play.window.Canvas;

public class panel implements Graphics {
    @Override
    public void draw(Canvas canvas) {

    }
}
